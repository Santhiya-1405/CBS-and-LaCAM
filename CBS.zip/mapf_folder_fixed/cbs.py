import heapq
import copy

from astar import astar


def detect(paths):

    maxlen = max(

        len(p)

        for p in paths

    )

    for t in range(maxlen):

        occupied = {}

        for i, p in enumerate(paths):

            pos = p[

                min(

                    t,

                    len(p)-1

                )

            ]

            if pos in occupied:

                return {

                    "type": "vertex",

                    "a1": occupied[pos],

                    "a2": i,

                    "cell": pos,

                    "time": t

                }

            occupied[pos] = i

        if t == 0:

            continue

        for i in range(len(paths)):

            for j in range(

                i+1,

                len(paths)

            ):

                p1 = paths[i]

                p2 = paths[j]

                a1 = p1[

                    min(

                        t-1,

                        len(p1)-1

                    )

                ]

                a2 = p1[

                    min(

                        t,

                        len(p1)-1

                    )

                ]

                b1 = p2[

                    min(

                        t-1,

                        len(p2)-1

                    )

                ]

                b2 = p2[

                    min(

                        t,

                        len(p2)-1

                    )

                ]

                if (

                    a1 == b2

                    and

                    b1 == a2

                ):

                    return {

                        "type": "edge",

                        "a1": i,

                        "a2": j,

                        "time": t,

                        "from1": a1,

                        "to1": a2,

                        "from2": b1,

                        "to2": b2

                    }

    return None


def cbs(

    grid,

    agents

):

    root = {

        "constraints": [],

        "paths": []

    }

    for i, a in enumerate(agents):

        p = astar(

            grid,

            i,

            a["start"],

            a["goal"],

            []

        )

        if p is None:

            return None

        root["paths"].append(p)

    root["cost"] = sum(

        len(x)

        for x in root["paths"]

    )

    queue = []

    heapq.heappush(

        queue,

        (

            root["cost"],

            0,

            root

        )

    )

    counter = 1

    while queue:

        _, _, node = heapq.heappop(

            queue

        )

        conflict = detect(

            node["paths"]

        )

        if conflict is None:

            return node["paths"]

        for agent in [

            conflict["a1"],

            conflict["a2"]

        ]:

            child = {

                "constraints": copy.deepcopy(

                    node["constraints"]

                ),

                "paths": copy.deepcopy(

                    node["paths"]

                )

            }

            if conflict["type"] == "vertex":

                child["constraints"].append(

                    {

                        "agent": agent,

                        "type": "vertex",

                        "cell": conflict["cell"],

                        "time": conflict["time"]

                    }

                )

            else:

                if agent == conflict["a1"]:

                    child["constraints"].append(

                        {

                            "agent": agent,

                            "type": "edge",

                            "from": conflict["from1"],

                            "to": conflict["to1"],

                            "time": conflict["time"]

                        }

                    )

                else:

                    child["constraints"].append(

                        {

                            "agent": agent,

                            "type": "edge",

                            "from": conflict["from2"],

                            "to": conflict["to2"],

                            "time": conflict["time"]

                        }

                    )

            p = astar(

                grid,

                agent,

                agents[agent]["start"],

                agents[agent]["goal"],

                child["constraints"]

            )

            if p is None:

                continue

            child["paths"][agent] = p

            child["cost"] = sum(

                len(x)

                for x in child["paths"]

            )

            heapq.heappush(

                queue,

                (

                    child["cost"],

                    counter,

                    child

                )

            )

            counter += 1

    return None