"""
Dynamic agent color generation.

The old UI had a hardcoded list of 8 RGB tuples and cycled through
them with `COLORS[i % len(COLORS)]`, so the 9th agent silently
reused agent 0's color and became visually indistinguishable from
it. This generates a new, well-separated color for any number of
agents on the fly using a golden-ratio hue rotation, so colors never
run out and never collide.
"""

import colorsys

GOLDEN_RATIO_CONJUGATE = 0.618033988749895


def generate_color(index, saturation=0.65, value=0.95):
    """Return a distinct, high-contrast RGB tuple for the given index."""
    hue = (index * GOLDEN_RATIO_CONJUGATE) % 1.0
    r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
    return (int(r * 255), int(g * 255), int(b * 255))
