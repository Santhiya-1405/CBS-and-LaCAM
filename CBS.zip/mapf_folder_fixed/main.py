import pygame

from config import (
    GRID_ROWS,
    GRID_COLS,
    CELL_SIZE,
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    GRID_WIDTH,
    FPS,
)
from ui import draw_screen
from cbs import cbs

pygame.init()

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("MAPF - CBS Simulator")

clock = pygame.time.Clock()

grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]
agents = []
temp = {}

mode = "Obstacle"
animating = False
show_stats = True
frame = 0
running = True
status_message = "Click grid to place obstacles. Press 2 to add agents."

NUM_KEYS = {
    pygame.K_1: 1, pygame.K_KP1: 1,
    pygame.K_2: 2, pygame.K_KP2: 2,
    pygame.K_3: 3, pygame.K_KP3: 3,
    pygame.K_4: 4, pygame.K_KP4: 4,
}

while running:
    clock.tick(FPS)

    if animating:
        valid = [a for a in agents if "path" in a]
        if valid:
            frame += 1
            mx = max(len(a["path"]) for a in valid)
            if frame >= mx:
                animating = False
        else:
            animating = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            key_num = NUM_KEYS.get(event.key)

            if key_num == 1:
                mode = "Obstacle"
                status_message = "Mode: Obstacle. Click cells to toggle walls."

            elif key_num == 2:
                mode = "Start"
                status_message = "Mode: Start. Click a cell to place agent start."

            elif key_num == 3:
                if len(agents) == 0:
                    status_message = "No agents yet - press 2 and click start/goal first."
                else:
                    for a in agents:
                        a.pop("path", None)
                    paths = cbs(grid, agents)
                    if paths:
                        for i, p in enumerate(paths):
                            agents[i]["path"] = p
                        status_message = f"CBS solved: {len(agents)} agent(s), cost {sum(len(p) for p in paths)}."
                    else:
                        status_message = "CBS found no solution for the current setup."

            elif key_num == 4:
                ok = any("path" in a for a in agents)
                if not ok:
                    status_message = "No solved paths yet - press 3 to run CBS first."
                else:
                    frame = 0
                    animating = True
                    status_message = "Animating..."

            elif event.key == pygame.K_g:
                show_stats = not show_stats
                status_message = f"Graph panel {'shown' if show_stats else 'hidden'}."

            elif event.key == pygame.K_r:
                grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]
                agents.clear()
                temp.clear()
                mode = "Obstacle"
                animating = False
                frame = 0
                status_message = "Reset: grid and agents cleared."

        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = pygame.mouse.get_pos()
            if x >= GRID_WIDTH:
                continue

            row = y // CELL_SIZE
            col = x // CELL_SIZE

            if row >= GRID_ROWS or col >= GRID_COLS:
                continue

            if mode == "Obstacle":
                grid[row][col] = 1 - grid[row][col]

            elif mode == "Start":
                temp["start"] = (row, col)
                mode = "Goal"
                status_message = f"Start set at {(row, col)}. Now click a goal cell."

            elif mode == "Goal":
                temp["goal"] = (row, col)
                agents.append(temp.copy())
                temp.clear()
                mode = "Obstacle"
                status_message = f"Agent {len(agents)} added. Press 2 to add another, or 3 to run CBS."

    draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message)

pygame.quit()
