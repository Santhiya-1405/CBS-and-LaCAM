import heapq

from config import max_search_time


def heuristic(a, b):

    return abs(

        a[0] - b[0]

    ) + abs(

        a[1] - b[1]

    )


def neighbours(node, grid):

    r, c = node

    rows = len(grid)

    cols = len(grid[0])

    dirs = [

        (-1, 0),

        (1, 0),

        (0, -1),

        (0, 1),

        (0, 0)

    ]

    out = []

    for dr, dc in dirs:

        nr = r + dr

        nc = c + dc

        if 0 <= nr < rows:

            if 0 <= nc < cols:

                if grid[nr][nc] == 0:

                    out.append(

                        (nr, nc)

                    )

    return out


def violates(

    agent,

    frm,

    to,

    time,

    constraints

):

    for c in constraints:

        if c["agent"] != agent:

            continue

        if c["type"] == "vertex":

            if (

                c["time"] == time

                and

                c["cell"] == to

            ):

                return True

        if c["type"] == "edge":

            if c["time"] == time:

                if (

                    c["from"] == frm

                    and

                    c["to"] == to

                ):

                    return True

    return False


def astar(

    grid,

    agent,

    start,

    goal,

    constraints

):

    open_set = []

    heapq.heappush(

        open_set,

        (0, start, 0)

    )

    parent = {}

    g = {

        (start, 0): 0

    }

    visited = set()

    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    MAX_TIME = max_search_time(rows, cols)

    while open_set:

        _, current, time = heapq.heappop(

            open_set

        )

        state = (

            current,

            time

        )

        if state in visited:

            continue

        visited.add(state)

        if current == goal:

            path = []

            s = state

            while s in parent:

                path.append(

                    s[0]

                )

                s = parent[s]

            path.append(start)

            path.reverse()

            return path

        if time > MAX_TIME:

            continue

        for nxt in neighbours(

            current,

            grid

        ):

            nt = time + 1

            if violates(

                agent,

                current,

                nxt,

                nt,

                constraints

            ):

                continue

            key = (

                nxt,

                nt

            )

            ng = g[state] + 1

            if (

                key not in g

                or

                ng < g[key]

            ):

                g[key] = ng

                parent[key] = state

                f = ng + heuristic(

                    nxt,

                    goal

                )

                heapq.heappush(

                    open_set,

                    (

                        f,

                        nxt,

                        nt

                    )

                )

    return None