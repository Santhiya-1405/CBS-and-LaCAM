"""
LaCAM high-level search.

Same algorithm as the source project. As with cbs.py, `solve_lacam`
gained an opt-in `collect_stats` flag: when True it returns
`(paths, stats)` where `stats` reports the iteration count and number
of joint-configuration nodes actually generated on *this* run, so it
can be compared fairly against CBS's own real counts. Default
behavior (`collect_stats=False`) is unchanged.

`solve()` is kept for standalone use (LaCAM with a CBS fallback,
useful outside the comparison tool) and is untouched.
"""

from config import LACAM_MAX_ITERATIONS, max_search_time
from distance_table import build_distance_tables
from pibt import pibt_timestep
from cbs import cbs as run_cbs


def _reconstruct(parent, node, agent_count):
    chain = []
    cur = node
    while cur is not None:
        chain.append(cur[0])  # cur = (config, parent_key, priorities)
        cur = parent.get(cur)
    chain.reverse()

    paths = [[] for _ in range(agent_count)]
    for config in chain:
        for i, pos in enumerate(config):
            paths[i].append(pos)
    return paths


def solve_lacam(grid, agents, max_iterations=LACAM_MAX_ITERATIONS, collect_stats=False):
    """Try to solve with LaCAM. Returns paths (or paths, stats if
    collect_stats), or None (or None, stats) on failure - caller
    decides whether to fall back."""

    def done(paths, iterations, nodes_generated):
        if not collect_stats:
            return paths
        return paths, {"iterations": iterations, "nodes_generated": nodes_generated}

    if not agents:
        return done(None, 0, 0)

    starts = tuple(a["start"] for a in agents)
    goals = tuple(a["goal"] for a in agents)
    n = len(agents)

    if starts == goals:
        return done([[s] for s in starts], 0, 1)

    dist_tables = build_distance_tables(grid, list(goals))
    rows, cols = len(grid), len(grid[0]) if grid else 0
    max_timesteps = max_search_time(rows, cols)

    priorities0 = tuple(0.0 for _ in range(n))

    root_key = (starts, priorities0)
    stack = [root_key]
    parent = {root_key: None}
    path_configs = {starts}
    depth = {root_key: 0}

    iterations = 0
    while stack and iterations < max_iterations:
        iterations += 1
        node_key = stack[-1]
        config, priorities = node_key

        if config == goals:
            return done(_reconstruct(parent, node_key, n), iterations, len(parent))

        if depth[node_key] >= max_timesteps:
            stack.pop()
            path_configs.discard(config)
            continue

        next_config = pibt_timestep(config, priorities, grid, list(goals), dist_tables)

        if next_config is None or next_config in path_configs:
            stack.pop()
            path_configs.discard(config)
            continue

        next_priorities = tuple(
            0.0 if next_config[i] == goals[i] else priorities[i] + 1.0
            for i in range(n)
        )

        next_key = (next_config, next_priorities)
        parent[next_key] = node_key
        depth[next_key] = depth[node_key] + 1
        stack.append(next_key)
        path_configs.add(next_config)

    return done(None, iterations, len(parent))


def solve(grid, agents, max_iterations=LACAM_MAX_ITERATIONS):
    """Standalone entry point: LaCAM first, CBS fallback on failure.
    Returns (paths, solver_name) or (None, None). Not used by the
    comparison tool itself (which runs each solver independently),
    but kept for parity with the source project.
    """
    paths = solve_lacam(grid, agents, max_iterations)
    if paths is not None:
        return paths, "LaCAM"

    fallback_paths = run_cbs(grid, agents)
    if fallback_paths is not None:
        return fallback_paths, "CBS (fallback)"

    return None, None
