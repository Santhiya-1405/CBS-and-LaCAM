"""
Head-to-head comparison of CBS and LaCAM.

Both solvers are given the exact same grid and agent list and are
timed independently, right here, right now - every number in the
result comes out of actually running that solver on this instance.
Nothing is pre-recorded or estimated: change the grid or the agents
and the next run_comparison() call reflects that automatically.

CBS is complete but replans a whole agent path per conflict, so it
tends to win on solution quality (guaranteed optimal sum-of-costs) and
lose on speed as conflicts pile up. LaCAM searches joint
configurations directly and is usually much faster, but it's not
guaranteed optimal and can occasionally fail outright on hard
instances (dense swaps/rotations PIBT can't untangle) - the
`solved` flag is what tells you if that happened on this run.
"""

import time

from cbs import cbs
from lacam import solve_lacam
from config import LACAM_MAX_ITERATIONS


def _cost_and_makespan(paths):
    """Cost = sum of path lengths (sum-of-costs, the standard MAPF
    objective). Makespan = length of the longest path minus 1 (moves
    the last agent to finish needs). Both computed from whatever paths
    were actually returned - None if there's no solution to measure."""
    if not paths:
        return None, None
    cost = sum(len(p) for p in paths)
    makespan = max(len(p) for p in paths) - 1
    return cost, makespan


def run_comparison(grid, agents, max_iterations=None):
    """Run CBS and LaCAM independently on (grid, agents).

    Returns a dict keyed by solver name ("CBS", "LaCAM"), each holding:
      paths, solved, time (seconds), cost, makespan, plus solver-
      specific search-effort stats (nodes_expanded/conflicts_found for
      CBS; iterations/nodes_generated for LaCAM).
    """
    if max_iterations is None:
        max_iterations = LACAM_MAX_ITERATIONS

    if not agents:
        return None

    results = {}

    t0 = time.perf_counter()
    cbs_paths, cbs_stats = cbs(grid, agents, collect_stats=True)
    elapsed = time.perf_counter() - t0
    cost, makespan = _cost_and_makespan(cbs_paths)
    results["CBS"] = {
        "paths": cbs_paths,
        "solved": cbs_paths is not None,
        "time": elapsed,
        "cost": cost,
        "makespan": makespan,
        "nodes_expanded": cbs_stats["nodes_expanded"],
        "conflicts_found": cbs_stats["conflicts_found"],
    }

    t0 = time.perf_counter()
    lacam_paths, lacam_stats = solve_lacam(grid, agents, max_iterations, collect_stats=True)
    elapsed = time.perf_counter() - t0
    cost, makespan = _cost_and_makespan(lacam_paths)
    results["LaCAM"] = {
        "paths": lacam_paths,
        "solved": lacam_paths is not None,
        "time": elapsed,
        "cost": cost,
        "makespan": makespan,
        "iterations": lacam_stats["iterations"],
        "nodes_generated": lacam_stats["nodes_generated"],
    }

    return results


def summarize(results):
    """One-line verdict derived from the actual results dict, not a
    fixed template - it changes depending on what really happened."""
    cbs_r = results["CBS"]
    lacam_r = results["LaCAM"]

    if not cbs_r["solved"] and not lacam_r["solved"]:
        return "Neither solver found a solution for this instance."
    if cbs_r["solved"] and not lacam_r["solved"]:
        return "Only CBS solved it - LaCAM exhausted its iteration budget."
    if lacam_r["solved"] and not cbs_r["solved"]:
        return "Only LaCAM solved it - CBS returned no path."

    faster = "CBS" if cbs_r["time"] < lacam_r["time"] else "LaCAM"
    if cbs_r["cost"] == lacam_r["cost"]:
        cheaper = "Tie on cost"
    else:
        cheaper = "CBS" if cbs_r["cost"] < lacam_r["cost"] else "LaCAM"
        cheaper += " has the lower cost"

    return f"{faster} was faster this run. {cheaper}."
