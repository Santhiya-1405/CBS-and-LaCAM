"""
Central configuration for the CBS vs LaCAM comparison app.

Same philosophy as the two source projects this is built from: no
magic numbers scattered through main.py / ui.py - every tunable value
lives here so changing grid size, timing budgets, etc. doesn't require
hunting through multiple files.
"""

# --- Grid ---
GRID_ROWS = 15
GRID_COLS = 15
CELL_SIZE = 40

GRID_WIDTH = GRID_COLS * CELL_SIZE
GRID_HEIGHT = GRID_ROWS * CELL_SIZE

# --- Sidebar / window ---
# Wider than the single-solver apps because the sidebar now has to fit
# a two-column (CBS vs LaCAM) stats table plus two small comparison
# charts, not just one solver's numbers.
SIDEBAR_WIDTH = 360
WINDOW_WIDTH = GRID_WIDTH + SIDEBAR_WIDTH
WINDOW_HEIGHT = max(GRID_HEIGHT, 620)

# --- Simulation speed ---
FPS = 8

# --- Colors (UI chrome, not agents - agents use color_utils) ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (210, 210, 210)
YELLOW = (255, 255, 0)
LIGHT_BLUE = (225, 235, 250)
RED = (220, 60, 60)

# Solver identity colors, used consistently everywhere a chart or
# label needs to distinguish "this is CBS" from "this is LaCAM".
CBS_COLOR = (70, 130, 200)
LACAM_COLOR = (220, 130, 40)

# --- A* / CBS search bound ---
# The longest an optimal path could ever need is bounded by the number
# of cells in the grid, so we give a generous multiple of that as
# headroom for detours around obstacles/constraints, derived from
# whatever grid is actually in use rather than a fixed constant.
def max_search_time(rows=GRID_ROWS, cols=GRID_COLS):
    return (rows * cols) * 2


# --- LaCAM search bound ---
# LaCAM searches a tree of joint configurations (one node per timestep
# for the whole team). This caps how many high-level nodes it will
# expand before giving up. Kept equal to the source project's value so
# neither solver gets a home-field advantage in the comparison.
LACAM_MAX_ITERATIONS = 5000
