import pygame

from config import (
    GRID_ROWS,
    GRID_COLS,
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    SIDEBAR_WIDTH,
    WHITE,
    BLACK,
    GRAY,
    YELLOW,
    LIGHT_BLUE,
    RED,
    CBS_COLOR,
    LACAM_COLOR,
)
from color_utils import generate_color

pygame.font.init()

title_font = pygame.font.SysFont(None, 28)
font = pygame.font.SysFont(None, 22)
small_font = pygame.font.SysFont(None, 19)


def draw_grid(screen, grid):
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            rect = pygame.Rect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            if grid[r][c]:
                pygame.draw.rect(screen, BLACK, rect)
            pygame.draw.rect(screen, GRAY, rect, 1)


def draw_agents(screen, agents, animating, frame):
    for i, agent in enumerate(agents):
        color = generate_color(i)

        sr, sc = agent["start"]
        gr, gc = agent["goal"]

        pygame.draw.circle(
            screen, color,
            (sc * CELL_SIZE + CELL_SIZE // 2, sr * CELL_SIZE + CELL_SIZE // 2),
            12,
        )
        pygame.draw.rect(
            screen, color,
            (
                gc * CELL_SIZE + CELL_SIZE // 4,
                gr * CELL_SIZE + CELL_SIZE // 4,
                CELL_SIZE // 2,
                CELL_SIZE // 2,
            ),
        )

        if "path" in agent:
            for r, c in agent["path"]:
                pygame.draw.circle(
                    screen, color,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    4,
                )

            if animating:
                idx = min(frame, len(agent["path"]) - 1)
                r, c = agent["path"][idx]
                pygame.draw.circle(
                    screen, YELLOW,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    16,
                )
                pygame.draw.circle(
                    screen, color,
                    (c * CELL_SIZE + CELL_SIZE // 2, r * CELL_SIZE + CELL_SIZE // 2),
                    12,
                )


def draw_sidebar_controls(screen, mode, agents, active_solver):
    x = GRID_WIDTH + 20
    y = 24

    screen.blit(title_font.render("CBS vs LaCAM", True, BLACK), (x, y))
    y += 40

    info = [
        "1 : Obstacle mode",
        "2 : New Agent",
        "3 : Run comparison",
        "4 : Animate",
        "5 : Switch view (CBS/LaCAM)",
        "G : Toggle stats panel",
        "R : Reset",
        "",
        f"Mode : {mode}",
        f"Agents : {len(agents)}",
        f"Viewing : {active_solver}",
    ]

    for text in info:
        screen.blit(font.render(text, True, BLACK), (x, y))
        y += 26

    return y + 6


def draw_status(screen, status_message, y):
    x0 = GRID_WIDTH + 20
    width = SIDEBAR_WIDTH - 40

    words = status_message.split(" ")
    lines, line = [], ""
    for w in words:
        trial = (line + " " + w).strip()
        if small_font.size(trial)[0] > width - 12 and line:
            lines.append(line)
            line = w
        else:
            line = trial
    if line:
        lines.append(line)
    lines = lines[:3]

    box_height = 20 + 18 * len(lines)
    box = pygame.Rect(x0, y, width, box_height)
    pygame.draw.rect(screen, LIGHT_BLUE, box)
    pygame.draw.rect(screen, BLACK, box, 1)

    ty = y + 6
    for line in lines:
        screen.blit(small_font.render(line, True, BLACK), (x0 + 6, ty))
        ty += 18

    return y + box_height + 10


def _fmt(value, digits=0, suffix=""):
    if value is None:
        return "-"
    if digits:
        return f"{value:.{digits}f}{suffix}"
    return f"{value}{suffix}"


def draw_comparison_table(screen, results, y):
    """Metric-by-metric CBS vs LaCAM table, built from whatever the
    actual comparison run produced - no fixed rows of pretend data."""
    x0 = GRID_WIDTH + 20
    width = SIDEBAR_WIDTH - 40

    screen.blit(font.render("Comparison (this run)", True, BLACK), (x0, y))
    y += 26

    col_metric = x0
    col_cbs = x0 + int(width * 0.42)
    col_lacam = x0 + int(width * 0.70)

    table_top = y
    header_h = 22
    pygame.draw.rect(screen, LIGHT_BLUE, (x0, y, width, header_h))
    screen.blit(small_font.render("Metric", True, BLACK), (col_metric + 4, y + 3))
    screen.blit(small_font.render("CBS", True, CBS_COLOR), (col_cbs + 4, y + 3))
    screen.blit(small_font.render("LaCAM", True, LACAM_COLOR), (col_lacam + 4, y + 3))
    y += header_h

    cbs_r = results["CBS"]
    lacam_r = results["LaCAM"]

    rows = [
        ("Solved", "Yes" if cbs_r["solved"] else "No", "Yes" if lacam_r["solved"] else "No"),
        ("Time (ms)", _fmt(cbs_r["time"] * 1000, 2), _fmt(lacam_r["time"] * 1000, 2)),
        ("Cost", _fmt(cbs_r["cost"]), _fmt(lacam_r["cost"])),
        ("Makespan", _fmt(cbs_r["makespan"]), _fmt(lacam_r["makespan"])),
        ("Nodes/Iters", _fmt(cbs_r["nodes_expanded"]), _fmt(lacam_r["iterations"])),
    ]

    for i, (label, cbs_val, lacam_val) in enumerate(rows):
        row_h = 20
        if i % 2 == 0:
            pygame.draw.rect(screen, (240, 240, 240), (x0, y, width, row_h))
        screen.blit(small_font.render(label, True, BLACK), (col_metric + 4, y + 2))
        screen.blit(small_font.render(cbs_val, True, BLACK), (col_cbs + 4, y + 2))
        screen.blit(small_font.render(lacam_val, True, BLACK), (col_lacam + 4, y + 2))
        y += row_h

    pygame.draw.rect(screen, BLACK, (x0, table_top, width, y - table_top), 1)

    return y + 8


def _draw_bar_pair(screen, x0, width, y, height, label, cbs_val, lacam_val, unit=""):
    """One labeled pair of bars (CBS vs LaCAM) for a single metric,
    scaled to whichever of the two values is larger right now."""
    screen.blit(small_font.render(label, True, BLACK), (x0, y))
    y += 18

    values = [v for v in (cbs_val, lacam_val) if v is not None]
    max_val = max(values) if values else 0

    bar_h = 14
    gap = 4
    max_bar_w = width - 70

    for name, val, color in (("CBS", cbs_val, CBS_COLOR), ("LaCAM", lacam_val, LACAM_COLOR)):
        bar_w = int((val / max_val) * max_bar_w) if (val is not None and max_val) else 0
        pygame.draw.rect(screen, color, (x0 + 60, y, bar_w, bar_h))
        pygame.draw.rect(screen, BLACK, (x0 + 60, y, max_bar_w, bar_h), 1)
        screen.blit(small_font.render(name, True, BLACK), (x0, y - 1))
        val_text = "-" if val is None else (f"{val:.2f}{unit}" if isinstance(val, float) else f"{val}{unit}")
        screen.blit(small_font.render(val_text, True, BLACK), (x0 + 65 + bar_w, y - 1))
        y += bar_h + gap

    return y + 6


def draw_comparison_charts(screen, results, y, bottom_limit):
    """Two small bar-chart panels (cost, time) so the size of the gap
    between solvers is visible at a glance, not just numeric."""
    x0 = GRID_WIDTH + 20
    width = SIDEBAR_WIDTH - 40
    panel_height = bottom_limit - y

    if panel_height < 90:
        return

    panel_rect = pygame.Rect(x0, y, width, panel_height)
    pygame.draw.rect(screen, LIGHT_BLUE, panel_rect)
    pygame.draw.rect(screen, BLACK, panel_rect, 1)

    cbs_r = results["CBS"]
    lacam_r = results["LaCAM"]

    inner_y = y + 8
    inner_y = _draw_bar_pair(
        screen, x0 + 8, width - 16, inner_y, panel_height,
        "Cost (sum of path lengths)", cbs_r["cost"], lacam_r["cost"],
    )
    _draw_bar_pair(
        screen, x0 + 8, width - 16, inner_y, panel_height,
        "Time (ms)", cbs_r["time"] * 1000, lacam_r["time"] * 1000, unit="ms",
    )


def draw_screen(screen, grid, agents, mode, animating, frame, show_stats, status_message, active_solver, results):
    screen.fill(WHITE)

    draw_grid(screen, grid)
    draw_agents(screen, agents, animating, frame)

    next_y = draw_sidebar_controls(screen, mode, agents, active_solver)

    if status_message:
        next_y = draw_status(screen, status_message, next_y)

    if show_stats and results:
        next_y = draw_comparison_table(screen, results, next_y)
        draw_comparison_charts(screen, results, next_y, GRID_HEIGHT - 10)
    elif show_stats:
        x0 = GRID_WIDTH + 20
        screen.blit(small_font.render("(press 3 to run CBS vs LaCAM)", True, BLACK), (x0, next_y))

    pygame.display.update()
