"""
Per-goal BFS distance tables.

LaCAM's low-level move-picking (PIBT) needs to know, for any cell, how
far that cell is from an agent's goal - not as the crow flies (like the
Manhattan heuristic A* uses), but the *true* shortest distance around
obstacles. That's because PIBT greedily commits to whichever neighbor
looks best right now with no backtracking at the single-step level, so
a heuristic that ignores walls can walk an agent straight into a dead
end.

We precompute one full BFS per distinct goal cell (goals repeat far
less often than the number of timesteps we'll query), and reuse it for
every agent that shares that goal and every timestep of the search.
"""

from collections import deque


def bfs_distances(grid, goal):
    """Shortest-path distance (in steps) from every reachable cell to `goal`,
    ignoring other agents - only static obstacles block movement."""
    rows = len(grid)
    cols = len(grid[0]) if rows else 0

    dist = {goal: 0}
    queue = deque([goal])

    while queue:
        r, c = queue.popleft()
        d = dist[(r, c)]

        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
                if (nr, nc) not in dist:
                    dist[(nr, nc)] = d + 1
                    queue.append((nr, nc))

    return dist


def build_distance_tables(grid, goals):
    """One BFS distance table per distinct goal cell."""
    tables = {}
    for goal in set(goals):
        tables[goal] = bfs_distances(grid, goal)
    return tables
