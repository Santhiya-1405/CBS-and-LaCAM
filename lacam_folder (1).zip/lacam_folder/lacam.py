"""
LaCAM high-level search.

CBS's high level searches over *constraint sets* (one A* re-plan per
branch). LaCAM instead searches over *joint configurations* - literally
"where is every agent right now" - one step forward in time per search
node:

  root node       = everyone at their start
  each child node = one more synchronized timestep, produced by
                    calling PIBT on the parent's configuration
  goal            = a node where every agent is standing on its goal

It's a depth-first search: keep pushing new timesteps forward via
PIBT. If PIBT can't produce a valid next step (or it produces a
configuration we've already visited on this path - a sign of a loop/
livelock), backtrack and try again with adjusted priorities.

`priorities` carries forward: any agent not on its goal yet has its
priority increased each step, so an agent that's been stuck the
longest always gets to move first the next time PIBT runs. This is
what prevents PIBT from repeatedly starving the same agent.

If LaCAM exhausts its iteration budget without finding a solution
(the known failure mode: rotational/adjacent-swap deadlocks PIBT
can't untangle on its own), we fall back to CBS, which is slower but
complete - it will always find a solution if one exists.
"""

from config import LACAM_MAX_ITERATIONS, max_search_time
from distance_table import build_distance_tables
from pibt import pibt_timestep
from cbs import cbs as run_cbs


def _reconstruct(parent, node, agent_count):
    chain = []
    cur = node
    while cur is not None:
        chain.append(cur[0])  # cur = (config, parent_key, priorities)
        cur = parent.get(cur)
    chain.reverse()

    paths = [[] for _ in range(agent_count)]
    for config in chain:
        for i, pos in enumerate(config):
            paths[i].append(pos)
    return paths


def solve_lacam(grid, agents, max_iterations=LACAM_MAX_ITERATIONS):
    """Try to solve with LaCAM. Returns list of paths, or None on failure
    (caller decides whether to fall back)."""
    if not agents:
        return None

    starts = tuple(a["start"] for a in agents)
    goals = tuple(a["goal"] for a in agents)
    n = len(agents)

    if starts == goals:
        return [[s] for s in starts]

    dist_tables = build_distance_tables(grid, list(goals))
    rows, cols = len(grid), len(grid[0]) if grid else 0
    max_timesteps = max_search_time(rows, cols)

    priorities0 = tuple(0.0 for _ in range(n))

    # DFS stack of (config, priorities, path_so_far_configs_set_for_cycle_check)
    root_key = (starts, priorities0)
    stack = [root_key]
    parent = {root_key: None}
    path_configs = {starts}  # configs used along the *current* DFS branch
    depth = {root_key: 0}

    iterations = 0
    while stack and iterations < max_iterations:
        iterations += 1
        node_key = stack[-1]
        config, priorities = node_key

        if config == goals:
            return _reconstruct(parent, node_key, n)

        if depth[node_key] >= max_timesteps:
            stack.pop()
            path_configs.discard(config)
            continue

        next_config = pibt_timestep(config, priorities, grid, list(goals), dist_tables)

        if next_config is None or next_config in path_configs:
            # PIBT got stuck, or we'd be revisiting a configuration
            # already on this branch (a loop) - dead end, backtrack.
            stack.pop()
            path_configs.discard(config)
            continue

        # Priority update: anyone not yet home waits longer -> higher priority next time.
        next_priorities = tuple(
            0.0 if next_config[i] == goals[i] else priorities[i] + 1.0
            for i in range(n)
        )

        next_key = (next_config, next_priorities)
        parent[next_key] = node_key
        depth[next_key] = depth[node_key] + 1
        stack.append(next_key)
        path_configs.add(next_config)

    return None  # exhausted the budget without reaching the goal config


def solve(grid, agents, max_iterations=LACAM_MAX_ITERATIONS):
    """
    Public entry point used by the UI.
    Returns (paths, solver_name) where solver_name is "LaCAM" or
    "CBS (fallback)", or (None, None) if neither could solve it.
    """
    paths = solve_lacam(grid, agents, max_iterations)
    if paths is not None:
        return paths, "LaCAM"

    fallback_paths = run_cbs(grid, agents)
    if fallback_paths is not None:
        return fallback_paths, "CBS (fallback)"

    return None, None
